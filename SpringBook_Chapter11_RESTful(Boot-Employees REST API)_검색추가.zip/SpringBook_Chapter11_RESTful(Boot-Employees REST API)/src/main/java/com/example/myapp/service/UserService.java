package com.example.myapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.myapp.mapper.UserMapper;
import com.example.myapp.model.User;

public class UserService {

    @Autowired
    private UserMapper userMapper;

    public List<User> getUsersByName(String name) {
        if (name == null || name.isEmpty()) {
            return userMapper.getAllUsers(); // 이름이 없으면 전체 사용자 목록 반환
        } else {
            return userMapper.getUsersByName(name); // 이름을 기준으로 사용자 목록 반환
        }
    }

}
