package com.example.myapp.controller;

import com.example.myapp.mapper.UserMapper;
import com.example.myapp.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserMapper userMapper;

    // 사용자 목록 조회
    @GetMapping("/users")
    public String getUsers(Model model) {
        List<User> users = userMapper.getAllUsers();
        model.addAttribute("users", users);
        return "userList";
    }

    // 폼 페이지
    @GetMapping("/form")
    public String showForm() {
        return "form";
    }

    // 폼 데이터 처리
    @PostMapping("/submit")
    public String submitForm(@RequestParam String name, @RequestParam String age, Model model) {
        User user = new User();
        user.setName(name);
        user.setAge(Integer.parseInt(age));
        
        userMapper.insertUser(user);  // 데이터베이스에 저장

        model.addAttribute("name", name);
        model.addAttribute("age", age);

        return "result";
    }
}
